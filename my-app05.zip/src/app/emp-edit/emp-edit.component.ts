import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-edit',
  templateUrl: './emp-edit.component.html',
  styleUrls: ['./emp-edit.component.css']
})
export class EmpEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
