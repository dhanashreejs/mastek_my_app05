module.exports = {
    DB: 'mongodb://localhost:27017/ng7crud'
 };
//  mongodb:} drivername
//  //localhost: hostname
//  27017:port number
//  /ng7crud:database 
